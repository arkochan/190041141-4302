#include "FiveYearMDS.hpp"

FiveYearMDS::FiveYearMDS()
{
}

FiveYearMDS::~FiveYearMDS()
{
}

float FiveYearMDS::get_maximumInterest() { return maximumInterest; }
void FiveYearMDS::set_maximumInterest(float input) { maximumInterest = input; }