#include "TwoYearMDS.hpp"

TwoYearMDS::TwoYearMDS()
{
}

TwoYearMDS::~TwoYearMDS()
{
}
float TwoYearMDS::get_maximumInterest() { return maximumInterest; }
void TwoYearMDS::set_maximumInterest(float input) { maximumInterest = input; }